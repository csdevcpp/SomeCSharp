﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TestTask_Sukhov
{
     public class Num_Str
    {
        public string num_str;
        public string str;


        public Num_Str(string num, string str)
        {
            this.num_str = num;
            this.str = str;

        }


        public Num_Str(string unsplited) // without checking yet
        {
            int i=0;
            while (unsplited.ElementAt(i) != '.')
            {
                i++;
            }

            this.num_str = unsplited.Substring(0, i);
            this.str = unsplited.Substring(i);

        }


        public string to_str()
        {
            return (this.num_str + this.str);
        }

        public static bool operator <(Num_Str a, Num_Str b)
        {
            if (a.str.CompareTo(b.str) < 0) return true;
            if (a.str.CompareTo(b.str) > 0) return false;
            else //(a.str.CompareTo(b.str) == 0)
            {
                if (int.Parse(a.num_str) < int.Parse(b.num_str)) return true;
                else return false;
            }

        }

        public static bool operator >(Num_Str a, Num_Str b)
        {
            if ((a < b) || (a.num_str==b.num_str && a.str==b.str)) return false;
            else return true;

        }

         //public static void 


    }

   
    
}
