﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using WebWorkers.Models;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace WebWorkers.Models.DAL
{
    public class FirmInitializer: DropCreateDatabaseIfModelChanges<FirmContext>
    {
        protected override void Seed(FirmContext context)
        {
            base.Seed(context);
            var dep = new List<Department>
            {
                new Department { DepartmentID = 1, Name = "IT", Description = "Main super it otdel" },
                new Department { DepartmentID = 2, Name = "Sytem Administration", Description = "Main super sys otdel" },
                new Department { DepartmentID = 3, Name = "Buhgalteria", Description = "We rules Your money" }
            };
            dep.ForEach(s => context.Departments.Add(s));

            var wor = new List<Worker>
            {
                new Worker { WorkerID = 1, FirtstName = "Trus", LastName = "Workerovich", DepartmentID = 1, Salary = 100500 },
                new Worker { WorkerID = 2, FirtstName = "Balbes", LastName = "Workerovich", DepartmentID = 1, Salary = 100600  },
                new Worker { WorkerID = 1, FirtstName = "Byvaliy", LastName = "Workerovich", DepartmentID = 1, Salary = 100700 },
                new Worker { WorkerID = 1, FirtstName = "Tygprogrammist", LastName = "Workerman", DepartmentID = 2, Salary = 10500 },
                new Worker { WorkerID = 1, FirtstName = "Nina", LastName = "Workerovna", DepartmentID = 3, Salary = 10505},

            };
            wor.ForEach(s => context.Workers.Add(s));

            try
            {
                context.SaveChanges();
            }
            catch
            {  }
            }
    }
}