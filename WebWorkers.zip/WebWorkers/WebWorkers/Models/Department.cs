﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace WebWorkers.Models
{
    public class Department
    {
        public int DepartmentID { get; set; }

        [Display(Name = "Department name")]
        public string Name { get; set; }

        public string Description { get; set; }
        public virtual ICollection<Worker> Workers { get; set; }
        public int? WorkersCount {
            get
            {
                int i = Workers.Count;
                return i;
            }
                
        }
       
        //public virtual Worker BossWorker { get; set; }
    }
}