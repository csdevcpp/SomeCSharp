﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
namespace WebWorkers.Models
{
    public class Worker
    {
        public int WorkerID { get; set; }
        
        public int DepartmentID { get; set; }


        [Display(Name = "First Name")]
        public string FirtstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        //[Display(Name = "Official Position")]
        //public string OfPosition { get; set; }
        //public DateTime AcceptionDate { get; set; }
        public double Salary { get; set; }
        public virtual Department Department { get; set; }


    }
}