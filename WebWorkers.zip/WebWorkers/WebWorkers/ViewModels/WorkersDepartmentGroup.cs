﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using WebWorkers.Models;

namespace WebWorkers.ViewModels
{
    public class WorkersDepartmentGroup
    {
        public Department Department {get; set;}
        public int WorkersCount { get; set; }
    }
   
}